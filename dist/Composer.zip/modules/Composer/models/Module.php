<?php

use OpenCrmItalia\SuiteTools\Functions\Modules\Verification;

class Composer_Module_Model extends Vtiger_Module_Model
{
    public function __construct()
    {
        /*
        if (!file_exists('modules/SuiteTools/SuiteTools.php')) {
            echo '<div class="alter alert-danger">Ti manca il suite tools</div>';
        }

        Verification::check("SuiteTaxRate", "1.0.1");*/
    }
}
