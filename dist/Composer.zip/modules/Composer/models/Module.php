<?php
class Composer_Module_Model extends Vtiger_Module_Model
{
    public function __constrct() {
        echo '<div class="alter alert-danger">Ti manca un modulo</div>>';
    }
}
